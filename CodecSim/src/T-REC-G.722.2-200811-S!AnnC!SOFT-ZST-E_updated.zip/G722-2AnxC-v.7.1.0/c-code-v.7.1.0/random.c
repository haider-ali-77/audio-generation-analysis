/* G.722.2 (2003/07) and Cor.1,2,3 | 26173-710 ANSI-C source code */

/*-------------------------------------------------------------------*
 *                         RANDOM.C									 *
 *-------------------------------------------------------------------*
 * Signed 16 bits random generator.								     *
 *-------------------------------------------------------------------*/

#include "typedef.h"
#include "basic_op.h"
#include "count.h"


Word16 Random(Word16 * seed)
{
    /* static Word16 seed = 21845; */

    *seed = extract_l(L_add(L_shr(L_mult(*seed, 31821), 1), 13849L));   move16();

    return (*seed);
}
